<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script type="text/javascript" src="js/main.js"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/font-awesome-line-awesome/css/all.min.css">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="/css/master.css">
    <link rel="stylesheet" href="/css/lineawsome/css/line-awesome.css">


</head>
<body>
    <div id="app">
      <nav class="mainnav navbar navbar-expand-md navbar-light shadow-sm">
          <div class="container">
              <a class="navbar-brand hometitle"href="/">
                  Home
              </a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                  <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <!-- Left Side Of Navbar -->
                  <ul class="navbar-nav mr-auto">

                  </ul>

                  <!-- Right Side Of Navbar -->
                  <ul class="navbar-nav ml-auto">
                      <!-- Authentication Links -->
                      <?php if(auth()->guard()->guest()): ?>
                          <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                          </li>
                          <?php if(Route::has('register')): ?>
                              <li class="nav-item">
                                  <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                              </li>
                          <?php endif; ?>
                      <?php else: ?>
                          <li class="nav-item dropdown">
                              <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                  <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                              </a>

                              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                     onclick="event.preventDefault();
                                                   document.getElementById('logout-form').submit();">
                                      <?php echo e(__('Logout')); ?>

                                  </a>

                                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                      <?php echo csrf_field(); ?>
                                  </form>
                              </div>
                          </li>
                      <?php endif; ?>
                  </ul>
              </div>
          </div>
      </nav>
      <main class="backgroundcolor">
        <div class="py-4 container-fluid maincontainer">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
      <main/>
      <footer class="bottom_nav container col-12" align="center">
        <a href="/"><i class="barra las la-igloo fa-3x col-2"></i></a>
        <a href="#"><i class="la la-camera fa-3x col-2"></i></a>
        <a href="/crearPost"><i class="barra la la-plus fa-3x col-2"></i></a>
        <a href="#"><i class="barra la la-comments fa-3x col-2"></i></a>
        <a href="/user/"><i class="barra la la-user-circle fa-3x col-2"></i></a>
      </footer>
    </div>
</body>
</html>
<?php /**PATH /home/mateodh/Documents/digitalfs/resources/views/layouts/app.blade.php ENDPATH**/ ?>