<div class="likesContainer row">
  <a href="#" style="width:12.5%">
    <i class="likesitem la la-thumbs-up fa-3x" style="width:100%"></i>
  </a>

  <a href="#" style="width:12.5%">
    <i class="likesitem la la-thumbs-down fa-3x" style="width:100%"></i>
  </a>

  <a href="#" style="width:12.5%">
    <i class="likesitem la la-share fa-3x" style="width:100%"></i>
  </a>

  <a href="#" style="width:12.5%">
    <i class="likesitem la la-ellipsis-v fa-3x" style="width:100%"></i>
  </a>
</div>
<?php /**PATH /home/mateodh/Documents/digitalfs/resources/views/icons.blade.php ENDPATH**/ ?>