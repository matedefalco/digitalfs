<?php $__env->startSection('content'); ?>
  <script src="/js/comments.js" charset="utf-8"></script>

  <section class='feed row align-items-center'>
    <article class='post col-8' >
        <div class="userContainer row">
          <div class="avatarContainer col-3">
            <img class="user_img" src="/storage/avatar_img/<?php echo e($post->user->avatar); ?>"alt="user img">
          </div>
          <div class="namecontainer col-9">
            <a class="username" href="/user/<?php echo e($post->user->id); ?>"><?php echo e($post->user->name); ?></a>
          </div>
        </div>
        <div class="mainImageContainer">
          <img src="/storage/post_img/<?php echo e($post->img); ?>" class="main_img" alt="main image">
        </div>
        <?php echo $__env->make('icons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </article>
    <div class="comments col-8">
      <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="avatarContainer col-2">
            <img class="user_img" src="/storage/avatar_img/<?php echo e($comment->user->avatar); ?>"alt="user img">
          </div>
          <div class="namecontainer col-3">
            <a class="username" href="/user/<?php echo e($comment->user->id); ?>"><?php echo e($comment->user->name); ?></a>
          </div>
          <div class="col-7">
            <?php echo e($comment->comment); ?>

          </div>
        </div>
        <br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <a href="/api/comment/post/<?php echo e($post->id); ?>" class="verMas">Show more</a>
    </div>
  </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mateodh/Documents/digitalfs/resources/views/post.blade.php ENDPATH**/ ?>