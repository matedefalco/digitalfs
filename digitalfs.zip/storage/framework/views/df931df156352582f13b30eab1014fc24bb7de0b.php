<?php $__env->startSection('content'); ?>


<?php $count = 0; ?>

  <section class='feed row align-items-center'>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($count == 0){ ?>
        <div class='usercontainer col-12'>
          <div class="row">
            <div class="avatarContainer col-3">
              <img class="user_img" src="/storage/avatar_img/<?php echo e($post->user->avatar); ?>"alt="user img">
            </div>
            <div class="namecontainer col-9">
              <a class="username" href="/user/<?php echo e($post->user->id); ?>"><?php echo e($post->user->name); ?></a>
            </div>
          </div>
        </div>
      <?php } ?>
      <article class='post col-xs-12 col-md-6 col-lg-6'>

        <div class="mainImageContainer">
          <a href="/post/<?php echo e($post->id); ?>">
            <img src="/storage/post_img/<?php echo e($post->img); ?>" class="main_img" alt="main image">
          </a>
        </div>

      <?php echo $__env->make('icons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </article>
      <?php $count++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mateodh/Documents/digitalfs/resources/views/user.blade.php ENDPATH**/ ?>